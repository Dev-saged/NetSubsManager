package com.abdullah.netsubsmanager

import android.app.Application

class App : Application()
