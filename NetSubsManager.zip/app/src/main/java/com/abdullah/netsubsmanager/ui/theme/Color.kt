package com.abdullah.netsubsmanager.ui.theme
import androidx.compose.ui.graphics.Color
val Seed = Color(0xFF006874)
