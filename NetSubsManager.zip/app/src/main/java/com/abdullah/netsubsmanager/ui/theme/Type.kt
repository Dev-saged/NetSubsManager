package com.abdullah.netsubsmanager.ui.theme
import androidx.compose.material3.Typography
val AppTypography = Typography()
